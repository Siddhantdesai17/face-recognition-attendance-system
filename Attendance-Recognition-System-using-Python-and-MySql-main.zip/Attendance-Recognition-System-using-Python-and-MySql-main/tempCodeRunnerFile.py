        # hlp_img_btn=Image.open(r"C:\Users\Aditya Kumar\Python-FYP-Face-Recognition-Attendence-System-master\Images_GUI\m1.png")
        # hlp_img_btn=hlp_img_btn.resize((180,180),Image.ANTIALIAS)
        # self.hlp_img1=ImageTk.PhotoImage(hlp_img_btn)

        # hlp_b1 = Button(bg_img,image=self.hlp_img1,cursor="hand2",)
        # hlp_b1.place(x=940,y=200,width=180,height=180)

        # hlp_b1_1 = Button(bg_img,text="Maria Khan",cursor="hand2",font=("tahoma",15,"bold"),bg="white",fg="navyblue")
        # hlp_b1_1.place(x=940,y=380,width=180,height=45)