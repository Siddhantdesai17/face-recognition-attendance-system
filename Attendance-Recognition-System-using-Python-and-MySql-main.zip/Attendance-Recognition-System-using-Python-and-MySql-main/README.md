It is a project which is made using python and mysql database
